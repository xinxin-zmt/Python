# 定义 Book 类
class Book:
    def __init__(self, title, author, isbn):
        # TODO:1
        self.title = title
        self.author = author
        self.isbn = isbn

    def __str__(self):
        return f"Title: {self.title}, Author: {self.author}, ISBN: {self.isbn}"

# 定义 Library 类
class Library:
    def __init__(self):
        self.books = []

    def add_book(self, book):
        # TODO:2  添加书
        self.books.append(book)
        print(f"Book added: {book}")

    def remove_book(self, isbn):
        for book in self.books:
            # TODO: 3 删除书
            if book.isbn == isbn:
                self.books.remove(book)
                print(f"Book removed: {book}")
                return
        print("Book not found.")

    def list_books(self):
        if not self.books:
            print("No books in the library.")
        else:
            for book in self.books:
                print(book)

# 辅助函数
def main():
    # 创建一个图书馆实例
    library = Library()

    # 添加几本书
    book1 = Book("The Great Gatsby", "F. Scott Fitzgerald", "978-3-16-148410-0")
    book2 = Book("To Kill a Mockingbird", "Harper Lee", "978-0-06-194741-2")
    book3 = Book("1984", "George Orwell", "978-0-451-52493-5")

    # TODO: 5 往库中添加书
    library.add_book(book1)
    library.add_book(book2)
    library.add_book(book3)

    # 列出所有书
    print("\nList of books in the library:")
    library.list_books()

    # 删除一本书
    isbn_to_remove = "978-0-06-194741-2"
    library.remove_book(isbn_to_remove)

    # 再次列出所有书
    print("\nList of books after removal:")
    library.list_books()

# 主程序入口
if __name__ == "__main__":
    main()