import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.ensemble import RandomForestRegressor

# 1. 加载数据
data = pd.read_csv('train.csv')

# 2. 数据探索
print(data.head())
print(data.describe())
print(data.isnull().sum())

# 3. 数据清洗
# 只对数值列填充均值
for col in data.select_dtypes(include=[np.number]).columns:
    data[col].fillna(data[col].mean(), inplace=True)
# 填充缺失值
data.fillna(data.mean(numeric_only=True), inplace=True)

# 检查是否有无穷大的值，并进行处理
data.replace([np.inf, -np.inf], np.nan, inplace=True)
data.fillna(data.mean(numeric_only=True), inplace=True)

# 特征工程：创建新的特征或转换特征
X = pd.get_dummies(data.drop('SalePrice', axis=1))
y = data['SalePrice']

# 对数值型特征进行对数转换
numeric_cols = X.select_dtypes(include=[np.number]).columns
X_log = X[numeric_cols].apply(lambda x: np.log1p(x))
X = pd.concat([X.drop(numeric_cols, axis=1), X_log], axis=1)

# 特征选择：选择与目标变量更相关的特征
selector = SelectKBest(score_func=f_regression, k='all')  # 选择所有特征进行初步特征选择
X_new = selector.fit_transform(X, y)

# 将选中的特征转换回 DataFrame
feature_names = selector.get_support(indices=True)
X_new_df = pd.DataFrame(X_new, columns=[X.columns[i] for i in feature_names])

# 数据预处理：对特征进行标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_new_df)
X_scaled_df = pd.DataFrame(X_scaled, columns=X_new_df.columns)

# 再次特征选择：选择与目标变量更相关的特征
selector = SelectKBest(score_func=f_regression, k=50)  # 选择50个最佳特征
X_final = selector.fit_transform(X_scaled_df, y)

# 4. 划分数据集
X_train, X_test, y_train, y_test = train_test_split(X_final, y, test_size=0.2, random_state=42)

# 5. 训练模型
model = LinearRegression()
model.fit(X_train, y_train)

# 6. 评估模型
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f'Mean Squared Error: {mse}')
print(f'R^2 Score: {r2}')

# 7. 可视化结果
plt.scatter(y_test, y_pred)
plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], color='red', linewidth=2)  # 添加y=x参考线
plt.xlabel('Actual Prices')
plt.ylabel('Predicted Prices')
plt.title('Actual vs Predicted Prices (Linear Regression)')
plt.show()

# 尝试其他模型，例如随机森林
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)
r2_rf = r2_score(y_test, y_pred_rf)
print(f'R^2 Score with Random Forest: {r2_rf}')