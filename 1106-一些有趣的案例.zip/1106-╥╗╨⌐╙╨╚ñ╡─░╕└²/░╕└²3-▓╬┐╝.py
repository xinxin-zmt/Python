
### 步骤 1: 导入所需库

```python
import torch
import torchvision
import torchvision.transforms as transforms
```
**注释**:
- `torch` 是 PyTorch 框架的核心库，用于张量操作和构建神经网络。
- `torchvision` 提供了许多与视觉相关的工具和数据集，如 CIFAR-10。
- `transforms` 用于对图像进行预处理，如转换为张量和归一化。

### 步骤 2: 加载和归一化 CIFAR-10 数据集

```python
transform = transforms.Compose(
    [transforms.ToTensor(),  # 将 PIL 图像或 numpy 数组转换为张量
     transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])  # 归一化张量图像

trainset = torchvision.datasets.CIFAR10(root='./data', train=True,
                                        download=True, transform=transform)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=4,
                                          shuffle=True, num_workers=2)

testset = torchvision.datasets.CIFAR10(root='./data', train=False,
                                       download=True, transform=transform)
testloader = torch.utils.data.DataLoader(testset, batch_size=4,
                                         shuffle=False, num_workers=2)

classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')
```
**注释**:
- `transforms.Compose` 组合多个变换操作。
- `transforms.ToTensor()` 将图像转换为张量，并将像素值从 [0, 255] 转换为 [0.0, 1.0]。
- `transforms.Normalize` 对张量图像进行归一化处理，使其均值为 0.5，标准差为 0.5。
- `torchvision.datasets.CIFAR10` 用于加载 CIFAR-10 数据集。
- `DataLoader` 用于创建可迭代的数据加载器，方便批量加载数据。
- `trainset` 和 `testset` 分别是训练集和测试集。
- `trainloader` 和 `testloader` 是数据加载器，用于批量加载数据。
- `classes` 列表包含了 CIFAR-10 数据集中的 10 个类别名称。

### 步骤 3: 定义卷积神经网络

```python
import torch.nn as nn
import torch.nn.functional as F

class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)  # 输入通道数 3，输出通道数 6，卷积核大小 5x5
        self.pool = nn.MaxPool2d(2, 2)   # 最大池化层，窗口大小 2x2，步长 2
        self.conv2 = nn.Conv2d(6, 16, 5) # 输入通道数 6，输出通道数 16，卷积核大小 5x5
        self.fc1 = nn.Linear(16 * 5 * 5, 120)  # 全连接层，输入特征数 16*5*5，输出特征数 120
        self.fc2 = nn.Linear(120, 84)    # 全连接层，输入特征数 120，输出特征数 84
        self.fc3 = nn.Linear(84, 10)     # 全连接层，输入特征数 84，输出特征数 10

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))  # 第一层卷积 + ReLU 激活 + 最大池化
        x = self.pool(F.relu(self.conv2(x)))  # 第二层卷积 + ReLU 激活 + 最大池化
        x = x.view(-1, 16 * 5 * 5)            # 将张量展平为一维向量
        x = F.relu(self.fc1(x))               # 第一个全连接层 + ReLU 激活
        x = F.relu(self.fc2(x))               # 第二个全连接层 + ReLU 激活
        x = self.fc3(x)                       # 第三个全连接层，输出分类结果
        return x

net = Net()
```
**注释**:
- `nn.Module` 是所有神经网络模块的基类。
- `nn.Conv2d` 定义卷积层，参数分别为输入通道数、输出通道数和卷积核大小。
- `nn.MaxPool2d` 定义最大池化层，参数分别为窗口大小和步长。
- `nn.Linear` 定义全连接层，参数分别为输入特征数和输出特征数。
- `forward` 方法定义了前向传播过程，输入张量 `x` 经过一系列卷积、激活、池化和全连接层的处理，最终输出分类结果。

### 步骤 4: 定义损失函数和优化器

```python
import torch.optim as optim

criterion = nn.CrossEntropyLoss()  # 交叉熵损失函数，适用于多分类任务
optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9)  # 随机梯度下降优化器
```
**注释**:
- `nn.CrossEntropyLoss` 是常用的分类损失函数。
- `optim.SGD` 是随机梯度下降优化器，`lr` 是学习率，`momentum` 是动量项。

### 步骤 5: 训练网络

```python
for epoch in range(2):  # 训练 2 轮
    running_loss = 0.0
    for i, data in enumerate(trainloader, 0):
        inputs, labels = data  # 获取输入图像和标签

        optimizer.zero_grad()  # 清零梯度

        outputs = net(inputs)  # 前向传播
        loss = criterion(outputs, labels)  # 计算损失
        loss.backward()  # 反向传播
        optimizer.step()  # 更新权重

        running_loss += loss.item()
        if i % 2000 == 1999:  # 每 2000 批次打印一次损失
            print('[%d, %5d] loss: %.3f' %
                  (epoch + 1, i + 1, running_loss / 2000))
            running_loss = 0.0

print('Finished Training')
```
**注释**:
- `enumerate` 用于遍历数据加载器，返回批次索引和数据。
- `optimizer.zero_grad()` 清零梯度，防止累积。
- `outputs = net(inputs)` 进行前向传播，得到预测输出。
- `loss = criterion(outputs, labels)` 计算损失。
- `loss.backward()` 进行反向传播，计算梯度。
- `optimizer.step()` 更新网络权重。
- `running_loss` 累加每批次的损失，每 2000 批次打印一次平均损失。

### 步骤 6: 测试网络

```python
correct = 0
total = 0
with torch.no_grad():  # 在测试过程中不需要计算梯度
    for data in testloader:
        images, labels = data
        outputs = net(images)
        _, predicted = torch.max(outputs.data, 1)  # 获取预测类别
        total += labels.size(0)
        correct += (predicted == labels).sum().item()  # 计算正确预测的数量

print('Accuracy of the network on the 10000 test images: %d %%' % (
    100 * correct / total))
```
**注释**:
- `torch.no_grad()` 用于禁用梯度计算，节省内存。
- `torch.max(outputs.data, 1)` 返回每一行的最大值及其索引，索引即为预测类别。
- `correct += (predicted == labels).sum().item()` 计算预测正确的数量。
- 最后输出测试集上的准确率。
